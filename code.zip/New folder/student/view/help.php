<!DOCTYPE html>
<html>
<title>
    Help
</title>

<head>
    <link rel="stylesheet" type="text/css" href="../css/mycss.css">
</head>

<body>
    <div class="box home">
        <a class="back" href="login.php"><img src="../resources/back.png" class="back"></a><br><br><br>
        <center>
            <button id="q1" class="hideshow">Q-1 Create tutor profile</button><br>
            <p id="ans1" style="display:none">Become a teacher by creating your profile here and tell us about yourself,
                your skills, subject expertise, qualifications, teaching ability and experience.
                Be sure to provide as much information as you can in your profile so that we can speed up the
                verification
                process and your profile starts showing up in the right spot when parents and students are searching for
                home tutors on our website</p>


            <button id="q2" class="hideshow">Q-2 Apply fir tution</button><br>
            <p id="ans2" style="display:none">
                Once your profile is complete, you can start browsing our latest TUITION JOBS page and start applying
                for
                the tuition jobs that best fits your skills, favorable location, class and subjects.
            </p>

            <button id="q3" class="hideshow">Q-3 Search Tutoring job</button><br>
            <p id="ans3" style="display:none">
                Search your desired tutoring jobs.
            </p>

            <button id="q4" class="hideshow">Q-4 Start tutoring and gwow your income</button><br>
            <p id="ans4" style="display:none">
                If parent like the demo session , you can continue tuition and start earning
            </p>
        </center>


    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="../js/jquery.js"></script>

</body>

</html>