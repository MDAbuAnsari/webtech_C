<!DOCTYPE html>
<html>
<title>
    Header
</title>

<head>
    <link rel="stylesheet" type="text/css" href="../css/mycss.css">
</head>

<body>
    <br>
    <div class="navigation">
        <nav>
            <div>
                <a href="home.php">Home</a>
                <a href="requestTution.php">Course Adding</a>
                <a href="viewprofile.php">View Profile</a>
                <a href="updateprofile.php">Update Profile</a>
                <a href="security.php">Password Change</a>
                <a href="index.php">Teacher List</a>
                <a href="file-upload.php">File Upload</a>
                <a href="per1.php">Permit</a>
               


                <a href="../control/logoutcheck.php" class="logout">Log Out</a>
            </div>
        </nav>
    </div>
    
</body>

<body>
  
</body>


</html>