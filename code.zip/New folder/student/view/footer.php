<!DOCTYPE html>
<html>
<title>
    Header
</title>

<head>
    <link rel="stylesheet" type="text/css" href="../css/mycss.css">
</head>

<body>
    <br>
    <div class="footer">
        <nav>
            
      <strong> &copy Abu Ansari <span style="color:rgb(238, 17, 17)">❤</span></strong>
     

        </nav>
    </div>
    
</body>

<body>
  
</body>


</html>